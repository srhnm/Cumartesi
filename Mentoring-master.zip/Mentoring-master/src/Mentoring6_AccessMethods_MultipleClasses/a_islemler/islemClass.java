package Mentoring6_AccessMethods_MultipleClasses.a_islemler;

public class islemClass {

    public int topla(int a, int b){

        return a+b;
    }

    public int cikar(int a, int b){
        return a-b;
    }

    public double bolme(double a,double b){

        return a/b;
    }
    public int carp(int a, int b){

        return a*b;
    }

}
