package Arrays_forEach_split.Arrays;

public class a_Arrays {
    public static void main(String[] args) {

        //TODO ------ ARRAYLER - DİZİLER -------

        //Temel yöntem

        int[] intArray = new int[3];

        intArray[0] = 40;
        intArray[1] = 50;
        intArray[2] = 60;

        //Daha düzenli ve basit yöntem

        int[] ikinciArray = {10,20,30};
                            //0  1  2


        //Spesifik eleman gösterme
        System.out.println("1. Array'in 3. eleman: " + intArray[2]);
        System.out.println("2. Array'in 2. eleman: " + ikinciArray[1]);
    }
}
