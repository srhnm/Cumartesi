package Arrays_forEach_split.Arrays;

public class c_Arrays {
    public static void main(String[] args) {

        //TODO Char array'i oluşturunuz. Array'in içindeki karakterler yan yana yazıldığında Selam yazsın.

        //TODO for loop kullanarak Array'in içindeki karakterleri yazdırınız.

        char[] harfler = {'S', 'e', 'l', 'a', 'm' };
        //                 0    1    2    3    4

        for (int i = 0; i < harfler.length; i++ ){
            System.out.print(harfler[i]);

        }



    }
}
