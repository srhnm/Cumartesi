package Arrays_forEach_split.Arrays;

import java.util.Arrays;

public class b_Arrays {
    public static void main(String[] args) {

      //TODO    ARRAY ELEMANLARINI STRING OLARAK YAZDIRMA

        String[] isimler = {"Ayşe", "Fatma", "Hayriye"};

        int[] yaslar = {18, 19, 20};

        System.out.println(Arrays.toString(isimler));
        System.out.println(Arrays.toString(yaslar));


            //Arrays.toString   methodu okunabilir şekilde yazdırmaya yarıyor.



    }
}
