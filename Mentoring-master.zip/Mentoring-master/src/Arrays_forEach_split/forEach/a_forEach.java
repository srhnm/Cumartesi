package Arrays_forEach_split.forEach;

public class a_forEach {
    public static void main(String[] args) {

        //TODO    for each loop ---- for each döngüsü

        // For each döngüsü hem kodun daha hızlı çalışmasını sağlıyor
        // hem de faha kolay okunabiliyor.

        String[] StringArrayi = {"Monitör", "Klavye", "Fare" };

        for (String yeniString : StringArrayi){
            System.out.println(yeniString);
        }



    }
}
