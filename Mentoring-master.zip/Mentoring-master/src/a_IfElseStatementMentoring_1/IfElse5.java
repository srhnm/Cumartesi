package a_IfElseStatementMentoring_1;

import java.util.Scanner;

public class IfElse5 {

    public static void main(String[] args) {


           /*
        VE - VEYA    && -- ||




        Ve = &&      Verilen koşulda,
             1. kosul  VE 2. kosulun beraber sağlanmaları gerekiyor.
             2.Iki koşul da sağlanırsa kod çalışır. kodun çalışması için ilk koşulun da SAĞLANMASI ZORUNLUDUR.



        Veya = ||                                                           Türkçe Klavyede = AltGR + - (tire)
                                                                                    Almanca Klavyede= AltGR + > işareti. (Sol shift tuşunun sağında, y harfinin solunda)
                Verilen   koşulda
                            1. koşul VEYA 2. koşul un olması yeterlidir.
                            Bir koşul sağlanırsa kod çalışır.
         */
        Scanner sc = new Scanner(System.in);



    }
}
