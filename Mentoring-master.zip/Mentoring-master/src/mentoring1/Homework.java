package mentoring1;

public class Homework {
    public static void main(String[] args) {
        // iki vize ve bir final olan sistemde not ortalamasi.
        // vizelerin ortalamasinin yuzde 30 u, finalin yuzde 70 i not ortalamayi verir


    }
}
