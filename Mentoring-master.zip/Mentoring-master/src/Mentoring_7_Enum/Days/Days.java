package Mentoring_7_Enum.Days;

public enum Days {

Pazartesi,
    Sali,
    Carsamba,
    Persembe,
    Cuma,
    Cumartesi,
    Pazar
}
