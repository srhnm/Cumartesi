package ArithmeticsOperators;

import java.util.Scanner;

public class b_Sum1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

       int num1 = sc.nextInt();
       int num2 = sc.nextInt();

       System.out.println(num1 + num2);

    }
}

//TODO       2 tane int oluşturunuz. Bu iki int'i toplayınız. Sonucu yazdırınız.
//TODO       Scanner kullanınız.

//5 dakika süre. 11.09