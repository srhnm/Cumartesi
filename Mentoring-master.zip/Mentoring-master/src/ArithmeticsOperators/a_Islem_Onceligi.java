package ArithmeticsOperators;

public class a_Islem_Onceligi {

    /*
            İşlem Önceliği;

        1. Parantez içindeki işlem

        2. Çarpma ve Bölme İşlemi

        3. Toplama ve Çıkarma işlemi

        Not: Eğer aynı önceliğe sahip işlemler varsa SOLDAN SAĞA doğru yapılır.





        >>>------------------------------------------>





        Örnek =    2 + 2 * 2 = 6

        Örnek =    2 / 2 * 2 = 2

        Örnek =   2 * (4) = 8





     */

}
