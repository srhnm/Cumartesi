package ArithmeticsOperators;

import java.util.Scanner;

public class f_reminder {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int num1 = sc.nextInt();
        int num2 = sc.nextInt();

        int num3 = num1 % num2;

        System.out.println(num3);

        // SAYININ 2 YE BÖLÜMÜNDEN KALAN 1 İSE TEK, 0 İSE ÇİFT SAYIDIR.
    }
}


//TODO      İki int'ın bölümünden kalanı yazdırınız.
//TODO      Scanner kullanınız.

