package ArithmeticsOperators;

import java.util.Scanner;

public class d_division2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        int num3 = sc.nextInt();

        System.out.println((num1 / num2) / num3);  //İŞLEM ÖNCELİĞİNDEN SOLDAN SAĞA BAŞLAR



    }
}

//TODO      3 adet INT oluşturun. Aralarında bölme işlemi yapınız. Sonucu yazdırınız.
//TODO      Scanner kullanınız.