package ArithmeticsOperators;

public class g_increment_decrement_operators {

    public static void main(String[] args) {

        //TODO Arttırma ve Azaltma

        System.out.println("-------------------Arttırma");
        int a = 1;
        System.out.println(++a);


        System.out.println("-------------------Azaltma");
        int b = 5;
        System.out.println(--b);


        System.out.println("-------------SORU-----------------");
        int elma = 20;
        int armut = 15;

        System.out.println(++elma + --armut);



    }
}
