package ab_ArrayMethodlari_2DArray_Mentoring3;

public class Array_Soru3_Odevler {
    public static void main(String[] args) {

        /*

iki ayrı int array oluşturun. İkisinin de eleman sayısı  5 olsun.

Elemanlar random atansın. (15 e kadar - 15 dahil)


2 int array'i de ekrana yazdırınız.  (1.dizi =
                                                        2.dizi=        )



Eğer iki arrayda ortak elemanlar varsa o elemanları yazdırınız.
Yoksa, "ortak eleman yoktur" mesajını konsola yazdırınız.

ÖRNEK:
1.Dizi : [1,2,3,4,5]
2.Dizi : [4,5,6,7,8]

ortak eleman: 4     ortak eleman: 5

    // TODO: 1  İpucu :

           Ortak eleman ararken oluşturacağınız koşula int count ekleyin. (int count = 0;)
Eğer ortak eleman varsa count++.
Eğer ortak eleman yoksa, count==0 ise           "ortak eleman yoktur".

         */




    }
}
