package ab_ArrayMethodlari_2DArray_Mentoring3.kahoot;

public class deneme2 {

    public static void main(String[] args) {

int [] [] array = {{22,33},{44,55}};

      System.out.println(array);



        }
    }

