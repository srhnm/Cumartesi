package Mentoring5_ArrayList_Sorular.Kahoot;

import java.util.ArrayList;

public class soru1 {
    public static void main(String[] args) {

        ArrayList<Integer> arrayList=  new ArrayList<>();

        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(4);
        arrayList.add(1,5);
        System.out.println(arrayList);

    }
}
