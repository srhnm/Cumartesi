package While_DoWhile.Do_While_Loops;

public class Do_While_Loops_2 {
    public static void main(String[] args) {
        //TODO---------- DO-WHILE

        int a = 10;

        do {

            System.out.println("a = " + a);

            a--;

        }

        while (a > 0);


    }
}
//---While ile farklı---
//While da koşul false ise hiç yazdırmıyor.
//Do While da bir kerede olsa yazdırıyor.

//YUKARIDAN AŞAĞIYA OKUYOR.

//Önce Do'yu okuyor sonra koşula
// yani while'a bakıyor.