package While_DoWhile.Do_While_Loops;

public class Do_While_Loops_1 {
    public static void main(String[] args) {

        //TODO----- WHILE İLE DO-WHILE'IN FARKI

        //while
        int i = 10;

        while (i < 5){
            System.out.println("Hello While");

        }

        //do-while
        int a = 10;

        do {
            System.out.println("Hello do-while");

        }
        while(a < 5);


    }
}
