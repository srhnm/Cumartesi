package While_DoWhile.Secenekli_Sorular;

public class Soru4 {
    public static void main(String[] args) {

    int x = 3;
    int i = 0;
    while (i < 3) {
        x += 1;  //x = x + 1
        i += 1;
    }
    System.out.println("x = " + x);
    System.out.println("i = " + i);

}
}

// A) x = 3
//    i = 0

// B) x = 6  ****
//    i = 3

// C) x = 9
//    i = 0
