package While_DoWhile.Secenekli_Sorular;

public class Soru2 {
    public static void main(String[] args) {


        int i = 0;
        while (i < 3) {
            System.out.println("Hey");
            i++;
        }
        System.out.println("bye");
    }
}
//  A) Hey  *****
//     Hey
//     Hey
//     bye

//  B) Hey
//     Bye

//  C) Hey
//     bye
//     Hey
//     bye
//     Hey
//     bye


