package While_DoWhile.Secenekli_Sorular;

public class Soru3 {
    public static void main(String[] args) {

        int i = 0;
        while (i < 0) {
            System.out.println("hi");
        }

    }
}

// A) Hata verecek

// B) Hiç bir output vermeyecek

// C) hi

