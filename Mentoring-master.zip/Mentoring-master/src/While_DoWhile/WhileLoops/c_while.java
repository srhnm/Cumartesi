package While_DoWhile.WhileLoops;

public class c_while {

}


//TODO STRING OLAN PIN kodunuzu kontrol eden bir kod yazınız.